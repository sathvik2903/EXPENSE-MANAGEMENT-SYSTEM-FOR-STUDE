# 💸 Student Expense Management System

A simple desktop app using Tkinter for tracking student expenses.

## Features
- Add, view, and delete expenses
- View pie chart of expense categories
- Data saved to JSON file

## Libraries Required
- tkinter
- tkcalendar
- matplotlib

## How to Run
```bash
pip install -r requirements.txt
python expense_tracker.py
```